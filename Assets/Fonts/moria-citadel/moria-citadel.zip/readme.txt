MORIA CITADEL by Russ Herschler
� 2002 - DragonFang
-------------------------------------------
This is my first font creation. And to be honest it is based
on an existing font. I have always wanted to create my own fonts
but never quite got the hang of it til now. MORIA CITADEL is based
on an old sheet of press-on type called STONEHENGE(#5620) from
Formatt. I looked high and low and could not find a computer font
of this typeface ANYWHERE (Share, Free or Commercial).

So I hauled out my trusty CorelDraw & Fontographer and had a mission.

This is the end result. It is version 1.0
The spacing may still need some work, as this face has some funky
decenders and extenders, but that is also the charm of the font.

Why the name MORIA CITADEL?
Well, the name Stonehenge is already established as a type name for
a great Tolkien-esque looking font, and I wanted to avoid confusion.
Also, CITADEL MINIATURES uses this typeface quite a bit for their
WARHAMMER line of games. So, and MORIA has a nice fantasy connotation
as well as fitting the feel of the font. It also shows off the cool
looking 'M' in the font.

If you like this font, visit my website...

http://www.dragonfang.com

You will be able to get the latest updates to the font there.
I also have a free archive of Character Sheets for most Role-Playing Games.

Well, hope you enjoy the font. It is my first, so be kind with your
comments and criticisim.

If you wish to pass this font around, feel free as long as this readme
is contained with it.


Thanks for listening to my rambling - Russ Herschler


 